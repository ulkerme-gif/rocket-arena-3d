# Rocket Arena 3D — iPad 9 ve GitHub Pages düzeltme

## Beyaz sayfa + çalışmayan oyun neden oluyor?

GitHub Pages kaynak dosyayı doğrudan `Deploy from a branch` yöntemiyle yayınlarsa Vite projelerinde CSS ve JS bundle edilmez. `src/main.js` CSS'i import eder ve `three` ile `@dimforge/rapier3d-compat` gibi bağımlılıkları kullanır. Ham HTML yayınlanır, ancak oyun çalışmaz.

## GitHub'da zorunlu adımlar (iPad Safari)

1. Repository > Settings > Pages.
2. `Build and deployment` altında `Source` değerini `Deploy from a branch` yerine **GitHub Actions** yap.
3. Repository > Actions > `Deploy Rocket Arena to GitHub Pages`. Yeşil onay gelene kadar bekle. Kırmızı çarpı varsa logu incele, site çalışıyor gibi görünse de başarılı yayın gerçekleşmemiştir.
4. Repo kökünde `.github/workflows/pages.yml`, `package.json`, `vite.config.js` bulunmalı. `.github` eksikse Codespaces terminalde `ls -la .github/workflows/` komutuyla kontrol et.
5. Yeni sürüm ZIP'ini repo köküne Codespaces dosya gezgininden upload ettiysen Codespaces terminalinde:

   unzip -oq rocket-arena-ipad-ready.zip
   rm rocket-arena-ipad-ready.zip
   git add -A
   git commit -m "Fix Pages and add iPad touch controls"
   git push

6. Site adresini Safari'de yeniden aç, yenile (gerekirse özel sekme). GitHub Actions'ın publish ettiği `dist/` içeriği yüklenmelidir.

## iPad kullanım

Bu pakette yatay iPad için ekranda çoklu dokunmaya uygun GAZ / GERİ / SOL / SAĞ / ZIPLA / BOOST / DRIFT / KAMERA tuşları vardır. Maç başladığında görünürler. Oyuna klavyeyle veya gamepad ile devam da mümkündür.

## Sınırlar

- GitHub Pages yalnızca statik istemciyi çalıştırır. ONLINE 1V1 için Render veya Raspberry Pi WebSocket backend gereklidir.
- Bu ortamda npm bağımlılıkları ve gerçek WebGL tarayıcı çalıştırması yapılamadı; statik ve bağımlılık gerektirmeyen testlerden geçmesi uçtan uca oyun garantisi değildir.
- iPad Safari performansını gerçek cihazda doğrulamak gerekir.
