import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { TouchControls } from '../src/input/TouchControls.js';

function fixture(action) {
  const listeners = new Map();
  const changes = [];
  const classes = new Set();
  const root = {
    classList: { toggle(name, disabled) { changes.push([name, disabled]); } },
    addEventListener(name, handler) { listeners.set(name, handler); },
    removeEventListener(name) { listeners.delete(name); },
  };
  const btn = {
    dataset: { touchAction: action },
    closest() { return this; },
    setPointerCapture() {},
    classList: { add(x) { classes.add(x); }, remove(x) { classes.delete(x); } },
  };
  const event = (id) => ({pointerId:id,target:btn,preventDefault(){}});
  return {listeners,changes,classes,root,btn,event};
}

test('multi-touch holds throttle while jump edge is consumed once', () => {
  const f=fixture('throttle'); const c=new TouchControls(f.root,true);c.setActive(true);
  f.listeners.get('pointerdown')(f.event(1));
  assert.equal(c.held('throttle'),true);
  assert.equal(c.consumeEdge('throttle'),true);
  assert.equal(c.consumeEdge('throttle'),false);
  f.listeners.get('pointerup')(f.event(1));
  assert.equal(c.held('throttle'),false);
  assert.equal(f.classes.has('pressed'),false);
  c.dispose();
  assert.equal(f.listeners.size,0);
});

test('touch buttons appear in local and online HTML with correct input actions', () => {
  for (const html of ['index.html','online.html']) {
    const page = readFileSync(new URL(`../${html}`,import.meta.url),'utf8');
    for (const action of ['throttle','reverse','steerLeft','steerRight','jump','boost','handbrake','ballCam']) {
      assert.match(page,new RegExp(`data-touch-action="${action}"`),`${html} missing ${action}`);
    }
  }
  const manager = readFileSync(new URL('../src/input/InputManager.js',import.meta.url),'utf8');
  assert.match(manager,/this\.touch\?\.setActive\(active\)/);
  assert.match(manager,/this\.touch\?\.held\(action\)/);
  assert.match(manager,/this\.touch\?\.consumeEdge\(action\)/);
});
