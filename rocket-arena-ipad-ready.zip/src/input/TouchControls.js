/**
 * Multi-touch, pointer-captured driving controls for tablets and phones.
 * Does not emulate DOM keyboard events and never takes focus from the game.
 */
export class TouchControls {
  constructor(root, isTouch = (typeof navigator !== 'undefined' && navigator.maxTouchPoints > 0) || (typeof matchMedia !== 'undefined' && matchMedia('(pointer:coarse)').matches)) {
    this.root = root;
    this.isTouch = !!isTouch;
    this.active = false;
    this.pointers = new Map(); // pointerId -> { action, element }
    this.edges = new Set();
    this.onDown = this._down.bind(this);
    this.onUp = this._up.bind(this);
    if (root) {
      root.addEventListener('pointerdown', this.onDown);
      root.addEventListener('pointerup', this.onUp);
      root.addEventListener('pointercancel', this.onUp);
      root.addEventListener('lostpointercapture', this.onUp);
    }
    this.setActive(false);
  }

  _down(e) {
    if (!this.active || !this.isTouch) return;
    const button = e.target.closest?.('[data-touch-action]');
    if (!button) return;
    const action = button.dataset.touchAction;
    if (!action || this.pointers.has(e.pointerId)) return;
    e.preventDefault();
    button.setPointerCapture?.(e.pointerId);
    this.pointers.set(e.pointerId, { action, element: button });
    button.classList.add('pressed');
    this.edges.add(action);
  }

  _up(e) {
    const pointer = this.pointers.get(e.pointerId);
    if (!pointer) return;
    e.preventDefault?.();
    this.pointers.delete(e.pointerId);
    if (![...this.pointers.values()].some(p => p.element === pointer.element)) {
      pointer.element.classList.remove('pressed');
    }
  }

  held(action) { return this.active && [...this.pointers.values()].some(p => p.action === action); }
  consumeEdge(action) {
    if (!this.active) return false;
    const has = this.edges.has(action);
    this.edges.delete(action);
    return has;
  }
  clear() {
    for (const pointer of this.pointers.values()) pointer.element.classList.remove('pressed');
    this.pointers.clear();
    this.edges.clear();
  }
  setActive(active) {
    this.active = !!active;
    if (!active) this.clear();
    this.root?.classList.toggle('hidden', !this.isTouch || !this.active);
  }
  dispose() {
    this.setActive(false);
    if (!this.root) return;
    this.root.removeEventListener('pointerdown', this.onDown);
    this.root.removeEventListener('pointerup', this.onUp);
    this.root.removeEventListener('pointercancel', this.onUp);
    this.root.removeEventListener('lostpointercapture', this.onUp);
  }
}
